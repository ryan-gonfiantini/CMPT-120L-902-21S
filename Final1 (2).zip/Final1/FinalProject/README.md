# Ryan's Final Project for Introduction to Programming
Instructions:
To run my web application, navigate to app.py on your local machine and click run. Upon executing the code, the Flask application will begin to run, command click on the line that says the web address on your local machine. After that, you will be on my web application!